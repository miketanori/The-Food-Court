package com.a00570682.thefoodcourt;

import java.util.*
import androidx.lifecycle.ViewModel

public class MainMenuViewModel : ViewModel(){

    private  val _foodRestaurants =



}